import React, { Component } from 'react';

class CheckBox extends Component {
  render() {
    return <div>CheckBox</div>;
  }
}

export default CheckBox;
