import React, { Component } from 'react';

class Tag extends Component {
  render() {
    const { _id, name, categoryID, groupID, description } = this.props;
    return <div />;
  }
}

export default Tag;
