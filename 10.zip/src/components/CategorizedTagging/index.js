import React, { Component } from 'react';
import Tagging from './Tagging';
import axios from 'axios';

class CategorizedTagging extends Component {
  state = {
    categories: [],
    groups: [],
    tags: [],
    selectedTags: [],
    searchedTags: [],
    errors: [],
    loading: false,
    toggle: false
  };

  componentDidMount() {
    this.fetchData();
  }

  fetchData = () => {
    this.setState({ loading: true });

    const baseURL = 'http://localhost:3002/data';
    axios
      .get(baseURL)
      .then(res => {
        this.setState({
          ...res.data,
          errors: [],
          loading: false
        });
      })
      .catch(err => {
        this.setState({
          loading: false,
          errors: this.state.errors.concat(err)
        });
      });
  };

  render() {
    // prettier-ignore
    const { categories, groups, tags, selectedTags, errors, loading, toggle } = this.state;

    const displayDropdown = () => {
      return (
        <div className="tagging-dropdown">
          {categories.map(category => (
            <div className="tagging-categorized-group">
              <div className="tagging-category">
                <span className="" />
              </div>
              <div className="tagging-group" />
            </div>
          ))}
        </div>
      );
    };

    return (
      <div className="tagging-container">
        <div className="tagging-search">
          <div className="tagging-group">
            {selectedTags.map(tag => (
              <Tagging {...tag} />
            ))}
          </div>
          <div className="tagging-input">
            <input type="text" />
          </div>
        </div>
        {toggle && displayDropdown()}
      </div>
    );
  }
}

export { CategorizedTagging };
