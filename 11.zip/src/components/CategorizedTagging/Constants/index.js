export const categorizedColors = [
  { id: 0, color: 'green-secondary' },
  { id: 1, color: 'pink' },
  { id: 2, color: 'yellow-dark' },
  { id: 3, color: 'green-dark' },
  { id: 4, color: 'blue-light' },
  { id: 5, color: 'black' },
  { id: 6, color: 'yellow-light' },
  { id: 7, color: 'blue-darker' },
  { id: 8, color: 'brown' },
  { id: 9, color: 'pink' },
  { id: 10, color: 'red' },
  { id: 11, color: 'red-lighter' },
  { id: 12, color: 'pink-dark' },
  { id: 13, color: 'green-light' },
  { id: 14, color: 'green-darker' },
  { id: 15, color: 'red-dark' }
];
